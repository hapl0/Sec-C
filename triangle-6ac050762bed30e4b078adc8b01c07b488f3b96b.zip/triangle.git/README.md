Petit challenge de stegano :
----------------------------

Le but est de retrouver le flag cacher dans ce triangle de Pascal (http://bit.ly/1iAHtSg)
En observant un peu le triangle le joueur s'apercevra vite que certaines valeurs sont fausses (la valeur centrale de chaque ligne impaire sauf la première et la troisième) et sont juste des valeurs décimal à passer en charactère ASCII pour avoir le flag. (qui est "PTri4ngl3")


Requirements :
--------------

* Ruby version 2.0.0-p247
* Le port 8080 de dispo (facilement modifiable si jamais il est nécessaire ailleurs)
* Déclencher le script avec `ruby triangle.rb`


Description joueurs :
---------------------

Ah les puissances, quelle belle architecture numérique. On dirait presque qu'elles peuvent nous parler ...
On dirait qu'elles essaient de vous parler par ici (si jamais) --> netcat xxx.xxx.xxx.xxx -p xxxx